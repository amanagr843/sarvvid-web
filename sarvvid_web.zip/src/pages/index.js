import ViewFiles from './ViewFiles';

export { ViewFiles };
