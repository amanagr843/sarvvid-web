import React from "react";

const fileChosenType = () => {
  return <div></div>;
};

export default fileChosenType;
